const falsis = require("aoi.js")
var fs = require('fs');
const bot = new falsis.Bot({
  token: process.env.token,
  prefix: "!",
  mobile: false,
  fetchInvites: true
})
bot.onLeave()
bot.onJoined()
bot.onMessage()
var reader = fs.readdirSync("./komutlar").filter(file => file.endsWith(".js"))
for (const file of reader) {
  const command = require(`./komutlar/${file}`)
  bot.command({
    name: command.name,
    aliases: command.aliases,
    bkz: command.bkz,
    code: command.code
  });
}
//durum
bot.status({
  text: "DURUM", //durum yazısı
  type: "PLAYING", //oynuyor kısmı
  status: "online", //presence
  time: 12 //burayı elleme
})
bot.status({
  text: "DURUM", //durum yazısı
  type: "PLAYING", //oynuyor kısmı
  status: "online", //presence
  time: 12 //burayı elleme
})
bot.status({
  text: "DURUM", //durum yazısı
  type: "PLAYING", //oynuyor kısmı
  status: "online", //presence
  time: 12 //burayı elleme
})
//variablelar
bot.variables({
param:"20", //son variable'da virgül olmaz
notum:"boş",
saas:"kapalı",
saasmsg:""
})
//uptime için
const keep_alive = require('./keep_alive.js')
//uptime için
//sa as
bot.command({
  name: "sa",
  aliases: ["selam","selamun aleykum","Selam"],
  code: `
$getServerVar[saasmsg]
$onlyIf[$getServerVar[saas]==açık]`,
 nonPrefixed: true
})