module.exports = {
  name: "notal",
  aliases: ["not-al","not al","Not al","Notal"],
  code:`
$description[başarıyla notun **$message** olarak ayarlandı notunu görmek için ___!notum___ veya ___!not görüntüle___ veya ___not-görüntüle___ yazabilirsin]
$argsCheck[>1;bir not girmelisin]
$setUserVar[notum;$message;$authorID]
$color[$random[1;99999]]`
}