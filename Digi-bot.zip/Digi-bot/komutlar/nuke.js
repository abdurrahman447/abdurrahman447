module.exports = {
name: "nuke",
code: `
$onlyPerms[managechannels;Bu komutu kullanmak için **Yönetici** iznine sahip olmalısın]
$deleteChannel[$channelID]
$cloneChannel[$channelID;$channelName;false]
$globalCooldown[10m;Bu komutu kullanabilmek için **%time%** beklemelisin]
`
}