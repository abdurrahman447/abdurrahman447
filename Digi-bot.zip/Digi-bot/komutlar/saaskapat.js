module.exports = {
  name: "sa-as-kapat",
  aliases: ["sa-as kapat","sa as kapat","saas kapat","saaskapat"],
  code: `
  $description[✅ | sa as sistemi başarıyla kapatıldı!]
  $color[$random[1;99999]]
  $setServerVar[saas;kapalı]`
}