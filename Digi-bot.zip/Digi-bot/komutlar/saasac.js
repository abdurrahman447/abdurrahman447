module.exports = {
  name: "sa-as-aç",
  aliases: ["sa-aç","saas-aç","saasac"],
  code: `
  $title[sa as sistemi]
  $description[✅ | sa as sistemi başarıyla açıldı birisi sa yazdığında cevabımı ayarlamak için ___!sa-as-mesaj___ yazabilirsin!]
$color[$random[1;99999]]
$setServerVar[saas;açık]
  `
}