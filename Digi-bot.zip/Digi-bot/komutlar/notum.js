module.exports = {
  name: "notum",
  aliases: ["not !not görüntüle","not-görüntüle"],
  code:`
$title[**NOTUN**]
$description[$getUserVar[notum;$authorID]]
$color[$random[1;99999]]
`
}