module.exports = {
  name: "anket",
  aliases: ["Anket","anket","anket-yap","anket-oluştur"],
 code: `
 
$onlyPerms[managechannels;Yönetici Yetkisine Sahip Değilsin!!]
$color[$random[1;999]]
$title[Anket Başladı]
$description[***$message***]
$addReactions[✅;❌]
@everyone & @here
$argsCheck[>1;ankette yazacak yazıyı yazmalısın!]
 `
}