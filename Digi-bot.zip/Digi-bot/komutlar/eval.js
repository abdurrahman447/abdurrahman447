module.exports = ({
  name:"eval",
  code:`$eval[$message]
  $onlyForIDs[$botOwnerID;...;Eval komutunu sadece sahibim kullanabilir.]`
})