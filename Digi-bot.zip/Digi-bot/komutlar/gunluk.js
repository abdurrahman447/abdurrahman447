module.exports = {
  name: "günlük",
  aliases: ["gunluk","günlük-para","günlükpara","daily"],
  code: `
  $title[günlük para]
  $description[ bugünkü günlük paran $random[100;500]
$setUserVar[param;$sum[$getUserVar[param;$authorID];$random[100;500]];$authorID]
$globalCooldown[24h;günlük paranı almak için  sonra günlük paranı alabilirsin]
$alternativeparsing
  `
}