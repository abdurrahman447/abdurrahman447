module.exports = {
 name: "param",
 aliases:["param","cüzdan","para"],
  code: `
  $title[cüzdanın]
  $description[
  💰 Paran : $getUserVar[param;$authorID]
  $color[$random[1;99999]]
  `
  
}