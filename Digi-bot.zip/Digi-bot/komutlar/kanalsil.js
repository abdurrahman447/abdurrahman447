module.exports = {
  name:"kanal-sil",
  aliases: ["kanalsil","Kanal sil","Kanalsil","Kanal-sil"],
  code:`
  $deleteChannels[$ChannelID]]
$description[Kanal başarıyla silindi✅]
$title[$message kanalı başarıyla silindi]]`
}