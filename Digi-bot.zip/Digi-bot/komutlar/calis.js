module.exports = {
  name: "çalış",
  aliases: ["calis","çalis","calış"],
  code: `
  $nomention
$title[çalıştın]
$description[
baban ile sanayide çalıştın ve
$random[150;12500] para kazandın
$color[$random[1;99999]]
$cooldown[5m;yoruldun 5 dakika sonra yine çalışabilirsin!]
]
  $setUserVar[param;$random[150;12500];$authorID]
  `
  
}