module.exports = {
  name: "sil",
  aliases: ["mesaj-sil","temizle","clear","msg-sil","msg sil","mesaj sil"],
  code: `
  $deletecommand
$clear[$message]
$onlyPerms[managemessages;Bu komutu kullanabilmek için Mesajları Yönet yetkisine sahip olman gerek.]
$deleteIn[3s]
$description[
✅ | başarıyla $message mesaj silindi!]
$argsCheck[>1;Lütfen bir sayı belirt.]
$onlyIf[$isNumber[$message]!=false;Girdiğin şey bir sayı değil.]
$color[$random[1;99999]]
  `
}