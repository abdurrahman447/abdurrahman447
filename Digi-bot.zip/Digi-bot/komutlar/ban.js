
module.exports = {
name: "ban",
code: `
$title[Kullanıcı Yasaklandı]
$description[
Yasaklanan Kullanıcı: **<@!$mentioned[1]>**

Yasaklayan Kullanıcı: **<@!$authorID>**
]
$footer[$username tarafından kullanıldı $addTimestamp]
$addTimestamp
$color[$random[0;99999]]
$ban[$mentioned[1]]
$onlyIf[$mentioned[1]>0;**Hata**: Birisini Etiketlemelisin]
$onlyIf[$mentioned[1]!=$authorID;**Hata**: Kendini Etiketleyemezsin]
$onlyPerms[admin;**Hata**: Bu Komutu Kullanmak İçin **Yönetici** İznine Sahip Olman Gerek]`
}