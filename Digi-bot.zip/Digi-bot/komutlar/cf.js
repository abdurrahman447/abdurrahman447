module.exports = {
  name: "cf",
  aliases: ["Cf","coinflip"],
  code: `
$suppressErrors[]
$cooldown[5s;<@$authorID>, biraz yavaşlamam lazım dostum!]
$setUserVar[param;$calculate[$getVar[param;$authorID]+$message[1]];$authorID]
$endif
$if[$randomText[Kazan;Kaybet;Boş]==Kazan]
**$nickname**, **$message** oynadı. Para dönüyor...$editIn[4s;**$nickname**, **$message** oynadı. Para dönüyor... ve **kazandı!!**]
$setUserVar[param;$calculate[$getVar[param;$authorID]-$message[1]];$authorID]
$endif
$if[$randomText[Kazan;Kaybet;Boş]==Kaybet]
**$nickname**, **$message** oynadı. Para dönüyor...$editIn[4s;**$nickname**, **$message** oynadı. Para dönüyor... ve hepsini **kaybetti** :c]
$setUserVar[param;$calculate[$getVar[param;$authorID]-$message[1]];$authorID]
$endif
$if[$randomText[Kazan;Kaybet;Boş]==Boş]
**$nickname**, **$message** oynadı. Para dönüyor...$editIn[4s;**$nickname**, **$message** oynadı. Para dönüyor ve... para dik geldi :O]
$endif
`
}