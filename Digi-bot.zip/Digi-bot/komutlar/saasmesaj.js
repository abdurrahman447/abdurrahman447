module.exports = {
  name: "sa-as-mesaj",
  aliases: ["saasmesaj","sa-as-msg","saasmsg"],
  code: `
  $description[✅ | başarıyla sa as mesajı $message olarak ayarlandı!]
  $color[$random[1;99999]]
  $setServerVar[saasmsg;$message]`
}